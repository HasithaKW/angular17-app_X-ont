// MIGRATION: app.component.ts — Angular 4 → Angular 17
// Original used selector 'my-app'; Angular 17 convention is 'app-root'.
// Http import removed — not needed in root component.

import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `<router-outlet />`
})
export class AppComponent {}
