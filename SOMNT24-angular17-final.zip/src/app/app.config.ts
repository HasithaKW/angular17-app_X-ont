import { ApplicationConfig } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { credentialsInterceptor } from './core/interceptors/credentials.interceptor';

// Session-based auth (matches Program.cs AddSession / SystemWebAdapters).
// credentialsInterceptor adds withCredentials:true to every /api request
// so the browser automatically sends the ASP.NET session cookie.
// No JWT / no Bearer token needed.
export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([credentialsInterceptor])),
    provideAnimations(),
  ]
};
