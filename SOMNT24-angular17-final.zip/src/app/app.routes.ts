// MIGRATION: Routes from Angular 4 AppModule RouterModule.forRoot([...])
// Original routes:
//   { path: 'list',                               component: ListComponent }
//   { path: 'new/:pageType',                      component: NewComponent  }
//   { path: 'new/:pageType/:retnType/:moduleCode', component: NewComponent  }
//
// Angular 17: lazy-loaded standalone components + auth guard added

import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },

  {
    path: 'login',
    loadComponent: () =>
      import('./features/login/login.component').then(m => m.LoginComponent)
  },

  {
    // MIGRATION: Preserved original route: /list
    path: 'list',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/return-type/list/list.component').then(m => m.ListComponent),
    title: 'Return Types'
  },

  {
    // MIGRATION: Preserved original routes:
    //   new/:pageType
    //   new/:pageType/:retnType/:moduleCode
    // Combined into one route; component reads optional params.
    path: 'new/:pageType',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/return-type/new/new.component').then(m => m.NewComponent),
    title: 'Return Type'
  },
  {
    path: 'new/:pageType/:retnType/:moduleCode',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/return-type/new/new.component').then(m => m.NewComponent),
    title: 'Return Type'
  },

  { path: '**', redirectTo: 'list' }
];
